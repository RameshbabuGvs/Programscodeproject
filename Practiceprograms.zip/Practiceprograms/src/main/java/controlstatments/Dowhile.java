package controlstatments;

public class Dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int y=10;//starting point
		do {
			System.out.println(y);
			y++;//incremental operation
		}
		
		while(y<=20);//end Condition
		System.out.println(y);
	}
}

 
