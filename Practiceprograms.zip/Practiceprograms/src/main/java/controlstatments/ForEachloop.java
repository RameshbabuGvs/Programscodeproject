package controlstatments;

public class ForEachloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] Ramesh={"jaswanth","Manasa","Sudheer"};
		
		
		/**int i[]= {10,20,30,40};
		for(int I:i) {
			System.out.println(I);
		}**/
		
		for(String ramesh:Ramesh) {
			System.out.println(ramesh);
		}
	}

}
