package controlstatments;

public class IFelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x=50;
		int y =50;
		if (x>y){
			System.out.println("x is greater than y");
		}
		else if (x < y) {
			System.out.println("x lessthan than y");
		}
		
		else if (x == y) {
			
			System.out.println("x equal to y");
		}
		else {
			System.out.println("x == y");
		}
	}

}
