package controlstatments;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int x=50;
		for(int i=x;i<=100;i++ ){
			//i=10
	        //10<10
	        //i++
	        System.out.println(i);
	        
	        
		}
	}

}
