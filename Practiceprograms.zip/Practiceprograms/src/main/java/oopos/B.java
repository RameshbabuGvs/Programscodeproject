package oopos;

public class B {

	public void Ram() {
		// TODO Auto-generated method stub
		
	}

}