package oopos;



public class A extends D {

	public void Ram() {
		// TODO Auto-generated method stub
}
	public static void main(String[] args) {
		
		A a=new A();
		System.out.println("HI");
	}
	
}
