package oopos;

public abstract class D {
	abstract void Ram();

	
}
