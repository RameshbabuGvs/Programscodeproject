package oopos;



public class C extends A{

}