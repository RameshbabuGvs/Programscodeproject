package javabasics;

public class Localvariable {
	static String str1="I am a class level variable";
	static String str="I am a class level variable";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1="I am local varible";
    System.out.println(str1);
    String str2="I am local varible";
    
    System.out.println(str);
    
    
	}
}
