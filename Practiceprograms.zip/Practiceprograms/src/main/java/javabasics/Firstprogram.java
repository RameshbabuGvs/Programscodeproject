package javabasics;

public class Firstprogram {
public static void main(String[]args){
		
		System.out.println("This is My first java program");
		System.out.println(10+20);
		
	}
}
