package javabasics;

public class Operators {
public static void main(String[]args){
		
		int a=10;
		int b=20;
		
		/*//Arthmetic Operations +,-,*./,%
		 System.out.println(a+b);//Adition Operation
		System.out.println(b-a);//Substraction Operation
		System.out.println(a*b);//Multiplication Operation
		System.out.println(a/b);//Division Operation
		System.out.println(a%b);//Modulus Operation
*/		
		
		
		/*//Relational Operations always Returns boolean Values true/false       < > <= >= != ==
		
		 System.out.println(a<b);//true
		 System.out.println(a>b);//false
		 
		 System.out.println(a<=b);//true
		 System.out.println(a>=b);//false
		 System.out.println(a==b);//false
		 System.out.println(a!=b);//true
*/		 
		 //Logical Operators are always  return boolean values true/False  1.a&&b,2.a||b,3.!A
		 
		 boolean x=true;
		 boolean y=false;
		 System.out.println(x&&y);
		 System.out.println(x||y);
		 System.out.println(!x);
		 System.out.println(!y);
		 
		
		
	}
	
}
