package javabasics;

public class Datatype {
public static void main(String[]args){
		
		int i =10;
		double d=10.55;
		char c='A';
		String s="Welcome to Javas";
		boolean b=true;
		System.out.println(i);
		System.out.println(d);
		System.out.println(c);
		System.out.println(s);
		System.out.println(b);
		
	}
}
