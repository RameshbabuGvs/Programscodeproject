package arrays;

public class StringArray {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s[]= new String[3];
		s[0]="Welcome";
		s[1]="to";
		s[2]="Java";
System.out.println(s.length);

for(String i:s){
	System.out.println(i);
}
	}

}
