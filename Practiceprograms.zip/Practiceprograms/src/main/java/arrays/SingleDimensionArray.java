package arrays;

public class SingleDimensionArray {
	public static void main(String[]args) {
		int arr[]={50,60,70,80};
		System.out.println(arr.length);
		
		for (int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+ " ");
		}
		
		
	}
}

