package publicpackage;



public class AccesModifiersPublic {

	public void Ram() {
		
	}
	public void Samatha() {}
	
	public void Mahesh() {}
	
	public void Mahesh1() {}
	
	public static void main(String[] args) {

AccesModifiers animalObj=new AccesModifiers();
		
		System.out.println(animalObj.animal1);


	}

	
}
