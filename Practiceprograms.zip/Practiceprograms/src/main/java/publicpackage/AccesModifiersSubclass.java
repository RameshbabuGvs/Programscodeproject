package publicpackage;

import javaclassesfrombasics.AccebilityPublic;

public class AccesModifiersSubclass  {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//AccesModifiersSubclass accesModifiersSubclass = new AccesModifiersSubclass();
		
		//System.out.println(accesModifiersSubclass.animal2);
		
		AccebilityPublic Ap=new AccebilityPublic();
		Ap.Ramesh();

	}

}
