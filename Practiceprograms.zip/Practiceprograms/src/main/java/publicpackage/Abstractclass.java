package publicpackage;

import javabasics.Parent;

class Parent1{
	public void m1() {
		System.out.println("Hi");
	}
	
}
class child{
	public void m2() {
		System.out.println("Hi Child");
	}
}
class Main{
public static void main(String []args) {
	Parents p= new Parents();
	//p.m1();
	
}}