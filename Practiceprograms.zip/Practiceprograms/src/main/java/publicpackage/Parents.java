package publicpackage;

public class Parents{
	
	
	public void m1() {
		System.out.println("Hi");
	}
	
}