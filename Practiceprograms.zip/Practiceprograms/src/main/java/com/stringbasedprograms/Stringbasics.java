package com.stringbasedprograms;



public class Stringbasics {
	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		/*
		 * String str="Ramesh"; System.out.println(str);
		 * 
		 * String str2="Babu"; System.out.println(str+str2); String str3=str+str2;
		 * System.out.println(str3); System.out.println(str.concat(str2));
		 * 
		 * String str4= new String("Babu");
		 * 
		 * System.out.println(str+str4);
		 */
  

  StringBuilder sb=new StringBuilder("Ram");
  sb.append("gvs");
  sb.append("AP");
  sb.append("INDIA");
  System.out.println(sb);

  

	}
}
