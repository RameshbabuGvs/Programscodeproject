package numbers;

public class LargestofthreeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a=50;
		int b=100;
		int c=30;
		if ((a>b)&&(a>c)){
			System.out.println("a is largest");
		}
		else if((b>a)&&(b>c)){
			System.out.println("b is largest");
		}
		else if ((c>a)&&(c>b)){
			System.out.println("C is larges");
		}
		
	}

}
