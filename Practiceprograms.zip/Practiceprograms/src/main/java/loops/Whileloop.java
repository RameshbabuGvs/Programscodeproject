package loops;

public class Whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//do while condition first check the condition if condition true moves else condition false not move
		int i =3;
		while (i<=10) {
       System.out.println(i);	
         i+=3;
		}
		
	}

}

