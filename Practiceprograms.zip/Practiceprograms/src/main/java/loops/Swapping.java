package loops;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=20;
		//int c=0;
		System.out.println("value of a is before swapping :"+a);
		System.out.println("value of b is before swapping :"+b);
		int c;
        c=a;//c is 10
		a=b;//a is 20
		b=c;//b is 20
		System.out.println("value of a is after swapping :"+a);
		System.out.println("value of b is after swapping :"+b);
		
		
	}

}
