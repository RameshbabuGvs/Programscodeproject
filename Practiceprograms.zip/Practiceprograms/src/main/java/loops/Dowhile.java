package loops;

public class Dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//if u want print only Odd numbers use this method
		
		int i=2;
		do{
			System.out.println(i);
			i+=2;
		}
		while(i<=10);
			System.out.println("not Passed");
	}
		
	}


