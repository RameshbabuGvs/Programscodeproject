package javaclassesfrombasics;

public class Operators {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * //un aray operator int y=10; System.out.println(y);
		 * System.out.println(y++);//10+1=10 System.out.println(++y);//1+10=12
		 * System.out.println(--y);//-1+12=11 System.out.println(y--);//11
		 */
		
		
		//arthemrtic operators===single line comment
		/*multiline comment*/
		/*
		int a=8;
		int b=4;
		int c=a+b;
		int d=a-b;
		int f=a*b;
		int g=a/b;
		int h=a%b;
		
		System.out.println("Addition of two varaible  "+  c);
		System.out.println("Substraction of two varaibles   "+d);
		System.out.println("Multiplication of two varaibles  " +f);
		System.out.println("Multiplication of two varaibles  " +g);
		System.out.println("Multiplication of two varaibles  " +h);*/
		
		/*//left Shift Operator
		int a=10;
		System.out.println(10<<2);//10*2^2==10*4=40
		System.out.println(10<<3);//10*2^3==80
		System.out.println((10<<4));//10*2^4==10*16=160
		//Right Shift operatp
		int b=10;
		System.out.println(10>>2);//10/2^2==10/4=2
		System.out.println(20>>3);//20/2^3==4
		System.out.println((50>>4));//10/2^4==10/16=160*/
		
		
		
		
	}

}
