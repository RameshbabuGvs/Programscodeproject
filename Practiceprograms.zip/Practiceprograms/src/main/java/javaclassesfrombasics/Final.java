package javaclassesfrombasics;



public class Final {

	final String Name="Sudheer";
	
	 void name() {
		String Name1="Babu";
	 }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Final f= new Final();
		System.out.println(f.Name);
	}

}
