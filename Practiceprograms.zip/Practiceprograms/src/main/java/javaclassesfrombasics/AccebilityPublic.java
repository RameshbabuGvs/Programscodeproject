package javaclassesfrombasics;



public class AccebilityPublic {


	public static void Ramesh() {
		System.out.println("How are youe Ramesh12345");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccebilityPublic Ap=new AccebilityPublic();
		Ap.Ramesh();
		

	}

}
