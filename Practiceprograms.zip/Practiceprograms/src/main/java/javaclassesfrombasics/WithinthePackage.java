package javaclassesfrombasics;



public class WithinthePackage {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccebilityPublic Ap=new AccebilityPublic();
		Ap.Ramesh();
		
	}
}
